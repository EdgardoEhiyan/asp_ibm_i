﻿
Namespace IDbConnection
    Interface ConnectionString

    End Interface
End Namespace
