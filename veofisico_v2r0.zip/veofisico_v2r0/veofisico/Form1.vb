﻿Imports IBM.Data.DB2.iSeries
Imports Microsoft.VisualBasic
Imports System
Imports System.Data
Imports System.IO
Imports System.Windows.Forms.DataVisualization.Charting



Public Class Form1
  
    
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Chart1.Visible = False
        Chart2.Visible = False
        Label30.Visible = False
        Label31.Visible = False


        marcaesta = 0
        MyBase.Show()
        TextBox4.Focus()
        'Form1.Refresh
        TextBox7.Text = "isysmodobj"
        
        
        ' aca cargo lo que esta grabado en el archivo de texto
        Const fic As String = "c:\as400sql\maquinas.txt"
        'Dim texto As String

        'Dim sr As New System.IO.StreamReader(fic)
        'texto = sr.ReadToEnd()
        'TextBox3.Text = texto
        'sr.Close()

        'Console.WriteLine(texto)
        '   -------------------------------------------------
        'lleno el check listobox
        Dim fichero As New System.IO.FileInfo(fic)
        Dim sr44 As New System.IO.StreamReader(fic)
        Dim VEO As String
        'sr44.ReadLine.FirstOrDefault()
        While Not sr44.EndOfStream
            VEO = sr44.ReadLine()
            CheckedListBox1.Items.Add(VEO)
        End While
        sr44.Close()

        ' aca cargo lo que esta grabado en el archivo de texto
        'Const fic2 As String = "c:\as400sql\maquinas.txt"
        'Dim texto2 As String

        ' Dim sr2 As New System.IO.StreamReader(fic2)
        ' texto2 = sr2.ReadToEnd()
        ' CheckedListBox1.Items.Add(texto2)
        ' sr2.Close()

        '       Console.WriteLine(texto2)

        ' Me.ReportViewer1.RefreshReport()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        

    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)




    End Sub

    Private Sub DataGridView1_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)
        ' mando los datos de la seleccion a los textbox, si encuentra nulos los reeplaza por vacios
        'If IsDBNull(DataGridView1.Rows(0).Cells(0).Value) Then
        ' TextBox1.Text = ""
        ' Else
        ' TextBox1.Text = DataGridView1.Rows(0).Cells(0).Value
        ' End If
        '
        '        If IsDBNull(DataGridView1.Rows(0).Cells(1).Value) Then
        ' TextBox2.Text = ""
        ' Else
        ' TextBox2.Text = DataGridView1.Rows(0).Cells(1).Value
        ' End If

        'If IsDBNull(DataGridView1.Rows(0).Cells(2).Value) Then
        ' TextBox3.Text = ""
        ' Else
        ' TextBox3.Text = DataGridView1.Rows(0).Cells(2).Value
        ' End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        Label11.Visible = True
        Label12.Visible = True
        Label11.Refresh()
        Label12.Refresh()

        ProgressBar1.Value = 0
        '  ProgressBar1.Visible = True
        '  ProgressBar1.Refresh()

        If TextBox4.Text = "" Or TextBox5.Text = "" Then
            MsgBox("You must complete the fields User and Password ", , "Asp")
            GoTo salir
        End If

        

        TextBox3.Refresh()
        Dim maquinaeip As String
        Dim maquina As String
        Dim ip As String
        ' Dim ip2 As String
        Dim cantidadm As Integer
        'Dim archivo As String = "c:\ptf400\ptfinforme.TXT"
        'Declaro que voy a abrir el archivo y voy a sobreescribir si el mismo exixte 
        '   Dim sw As New System.IO.StreamWriter(archivo, False)
        Dim salida As String
        Dim todo As String
        Dim conector As String


        ' Leo el textbox3 en donde estan las maquinas
        ' Dim t() As String
        ' t = Split(TextBox3.Text, vbCrLf)
        ' cantidadm = UBound(t)
        'ProgressBar1.Maximum = cantidadm
        ' For cuenta = 0 To UBound(t)
        ' maquinaeip = t(cuenta)
        ' Dim ArrCadena As String() = maquinaeip.Split(";")
        ' TextBox3.Refresh()
        ' maquina = ArrCadena(0)
        ' If maquina = "" Then
        ' GoTo salgo
        ' End If

        If marcaesta = 0 Then

            MsgBox("You must select one Lpar ", , "SQL")
            GoTo salir
        End If


        'ip = ArrCadena(1)
        ip = ip2



        ' Debug.Print(t(cuenta))
        '  Next cuenta
        'salgo:


        '---- ES USBAX3 ---------------------------------------------
        ' crear en el iseries este file  (nombre :PTFW2 en MSOPS)
        '     A          R PTFW                  
        '     A            NOMBRE       140A     
        '------------------------------------------------------------

        userx = TextBox4.Text
        passx = TextBox5.Text

        Dim userpass As String
        userpass = "userid=" + userx + ";" + "password=" + passx + ";"

        'Dim archivoauxiliar As String
        'Dim archivoauxiliar2 As String

        Dim ejecutox As String
        Dim ejecutox2 As String

        Dim copia As String
        Dim copia2 As String




        '    ejecutox = "DSPPTF LICPGM" + "(" + TextBox43.Text + ")" + " SELECT" + "(" + TextBox44.Text + ")" + " OUTPUT(*PRINT)"
        '   ejecutox2 = "CALL QSYS.QCMDEXC('" + ejecutox + "', " + ejecutox.Length.ToString("0000000000") + ".00000" + ")"

        ' copia = "cpysplf file(qsysprt) tofile(MSOPS/PTFW2) JOB(Q1WWT/QPRTJOB) SPLNBR(*LAST)"
        ' copia2 = "CALL QSYS.QCMDEXC('" + copia + "', " + copia.Length.ToString("0000000000") + ".00000" + ")"

        'userx = "Q1WWT"
        'passx = "CUERVO5ALB"
        userpass = "userid=" + userx + ";" + "password=" + passx + ";"

        conector = "DataSource=" + ip + ";" + " AllowUnsupportedChar=true" + ";"
        '            conector = "DataSource=" + ip + ";"

        Dim thisConnection12 As New iDB2Connection(
              conector +
               userpass +
              "LibraryList=" + TextBox7.Text)
        thisConnection12.Open()


        ' Dim strSelectStr = New IBM.Data.DB2.iSeries.iDB2Command(ejecutox2, thisConnection12)
        ' strSelectStr.ExecuteNonQuery()
        ' strSelectStr.Dispose()

        ' strSelectStr = New IBM.Data.DB2.iSeries.iDB2Command(copia2, thisConnection12)
        ' strSelectStr.ExecuteNonQuery()
        ' strSelectStr.Dispose()


        'Dim thisCommand As New iDB2Command(TextBox6.Text, thisConnection12)
        'thisCommand.CommandTimeout = 0

        Dim thisReader As iDB2DataReader
        Try
            '   thisReader = thisCommand.ExecuteReader()
        Catch ex As Exception
            MsgBox("Verifique la sentencia SQL por favor" & vbCrLf & ex.Message)
            GoTo salir

        End Try
        Try
            Dim dt As New DataTable("consulta") ' le puse PTFW2 pero se puede llamar de cualquier nombre funciona igual
            'Dim dt As New DataTable("pirulo")
            dt.Load(thisReader)


            '//////////////////////////////////////////


            DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None
            Dim col As DataGridViewComboBoxColumn = New DataGridViewComboBoxColumn

            col.AutoSizeMode = DataGridViewAutoSizeColumnMode.None



            '//////////////////////////////////////////


            DataGridView1.DataSource = dt
            thisReader.Close()

            thisConnection12.Close()
        Catch ex As Exception

            MsgBox("Tabla con datos invalidos " & vbCrLf & ex.Message)
        End Try






        ' ---------------------------------------------------


        ProgressBar1.Value = ProgressBar1.Value + 1
        ProgressBar1.Refresh()
        'Next cuenta

salgo:
        Try
        Catch ex As Exception
            ProgressBar1.Value = ProgressBar1.Value + 1
            ProgressBar1.Refresh()


            '      sw.Close()
            ProgressBar1.Visible = False
            ProgressBar1.Refresh()
        End Try
        GoTo salir
salir:

        Label11.Visible = False
        Label12.Visible = False
        Label11.Refresh()
        Label12.Refresh()

    End Sub



   

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        

    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        
        '--------------------------------------------------------------------------------------
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        
    End Sub

   

    Private Sub TextBox3_TextChanged(sender As System.Object, e As System.EventArgs)

    End Sub

    Private Sub Button3_Click_1(sender As System.Object, e As System.EventArgs)

    End Sub

    Private Sub Button3_Click_2(sender As System.Object, e As System.EventArgs)
        End
    End Sub

    Private Sub Timer1_Tick(sender As System.Object, e As System.EventArgs)


    End Sub

    Private Sub ProgressBar1_Click(sender As System.Object, e As System.EventArgs) Handles ProgressBar1.Click

    End Sub

    Private Sub ComboBox1_Click(sender As Object, e As System.EventArgs)

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As System.Object, e As System.EventArgs)

       
    End Sub

    Private Sub Button4_Click_2(sender As System.Object, e As System.EventArgs)
       
    End Sub

    Private Sub Button5_Click_1(sender As System.Object, e As System.EventArgs)

    End Sub
   

    Private Sub Button6_Click_1(sender As System.Object, e As System.EventArgs)
       
    End Sub

    Private Sub Button1_Click_1(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Const fic As String = "c:\as400sql\maquinas.txt"
        'Dim texto As String = "Pablito tenía una moto con un pito."
        Dim grabo As String
        Dim sw As New System.IO.StreamWriter(fic, True)

        If TextBox1.Text = "" Or TextBox2.Text = "" Then
            MsgBox("Complete both LPAR name and IP fields ")
            sw.Close()
            GoTo salir4
        End If

        grabo = TextBox1.Text + ";" + TextBox2.Text

        sw.WriteLine(grabo)
        sw.Close()

        MsgBox("Lpar Added ")
        CheckedListBox1.Items.Clear()
        'Const fic As String = "c:\ptf400\maquinas.txt"
        'Dim texto As String

        'Dim sr As New System.IO.StreamReader(fic)
        'texto = sr.ReadToEnd()
        'TextBox3.Text = texto
        'sr.Close()

        'Console.WriteLine(texto)
        Dim fichero As New System.IO.FileInfo(fic)
        Dim sr44 As New System.IO.StreamReader(fic)
        Dim VEO As String
        'sr44.ReadLine.FirstOrDefault()
        While Not sr44.EndOfStream
            VEO = sr44.ReadLine()
            CheckedListBox1.Items.Add(VEO)
        End While
        sr44.Close()
        CheckedListBox1.Update()
        CheckedListBox1.Refresh()
        TextBox1.Text = ""
        TextBox2.Text = ""
salir4:
    End Sub

    Private Sub Button4_Click_1(sender As System.Object, e As System.EventArgs)

        If DataGridView1.RowCount = 0 Then
            MessageBox.Show("El datagridview esta vacio")
        Else
            If Directory.Exists("C:\as400sql") = False Then ' si no existe la carpeta se crea
                Directory.CreateDirectory("C:\as400sql")
            End If
            Dim sFile As String = "C:\as400sql\Salidatexto.txt"
            If File.Exists(sFile) = True Then 'Si el archivo existe, lo elimina antes
                My.Computer.FileSystem.DeleteFile(sFile, FileIO.UIOption.OnlyErrorDialogs, _
                                                  FileIO.RecycleOption.DeletePermanently, FileIO.UICancelOption.DoNothing)
            End If


            'Const Dat As String = ("C:\Registro.txt")
            ' GERENANDO EL ARCHIVO 
            Using f As New IO.StreamWriter(sFile, True)

                ' AGREGANDO LAS COLUMNAS 
                Dim col As String = ""
                ' AGREGANDO LAS FILAS 
                Dim row As String = ""
                Dim i As Integer = 0
                For Each r As DataGridViewRow In DataGridView1.Rows
                    For Each c As DataGridViewColumn In DataGridView1.Columns

                        'row = row & "'" & Convert.ToString(r.Cells(c.HeaderText).Value) & vbTab
                        row = row & Convert.ToString(r.Cells(c.HeaderText).Value) & vbTab
                    Next
                    If i < DataGridView1.Rows.Count - 1 Then row &= Environment.NewLine
                Next

                'AGREGANDO LA INFORMACION 
                f.WriteLine(row)
                MessageBox.Show("El archivo SALIDATEXTO.txt ha sido creado en la carpeta C:\as400sql ")
            End Using
        End If
    End Sub

    Private Sub Button6_Click_2(sender As System.Object, e As System.EventArgs)

    End Sub

    Private Sub Button7_Click(sender As System.Object, e As System.EventArgs)

    End Sub

    Private Sub TextBox3_TextChanged_1(sender As System.Object, e As System.EventArgs) Handles TextBox3.TextChanged

    End Sub

    Private Sub CheckedListBox1_ItemCheck(sender As Object, e As System.Windows.Forms.ItemCheckEventArgs) Handles CheckedListBox1.ItemCheck
        Dim veochk As String
        Dim veochk2 As String

        If e.NewValue = CheckState.Checked Then
            For i As Integer = 0 To Me.CheckedListBox1.Items.Count - 1 Step 1
                If i <> e.Index Then
                    veochk = e.Index
                    borrar = e.Index   'esta variable global la uso para eliminar
                    veochk2 = CheckedListBox1.Text
                    Dim ArrCadena As String() = veochk2.Split(";")
                    ip2 = ArrCadena(1)
                    marcaesta = 1
                    Me.CheckedListBox1.SetItemChecked(i, False)
                End If
            Next i
        End If
    End Sub

    Private Sub CheckedListBox1_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles CheckedListBox1.SelectedIndexChanged

    End Sub

    Private Sub DataGridView1_DataError(sender As Object, e As System.Windows.Forms.DataGridViewDataErrorEventArgs)

        If (e.Context _
                  = (DataGridViewDataErrorContexts.Formatting Or DataGridViewDataErrorContexts.PreferredSize)) Then
            e.ThrowException = False
            DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None
            Dim col As DataGridViewComboBoxColumn = New DataGridViewComboBoxColumn

            col.AutoSizeMode = DataGridViewAutoSizeColumnMode.None

        End If

        ' MessageBox.Show("Error happened " & e.Context.ToString())
        ' If (e.Context = DataGridViewDataErrorContexts.Commit) _
        '     Then
        ' MessageBox.Show("Commit error")
        ' End If
        ' If (e.Context = DataGridViewDataErrorContexts _
        '     .CurrentCellChange) Then
        ' MessageBox.Show("Cell change")
        ' End If
        ' If (e.Context = DataGridViewDataErrorContexts.Parsing) _
        '     Then
        ' MessageBox.Show("parsing error")
        ' End If
        ' If (e.Context = _
        '     DataGridViewDataErrorContexts.LeaveControl) Then
        'MessageBox.Show("leave control error")
        'End If

        '        If (TypeOf (e.Exception) Is ConstraintException) Then
        ' Dim view As DataGridView = CType(sender, DataGridView)
        ' view.Rows(e.RowIndex).ErrorText = "an error"
        ' view.Rows(e.RowIndex).Cells(e.ColumnIndex) _
        ' .ErrorText = "an error"

        'e.ThrowException = False
        'End If



    End Sub

    Private Sub Button7_Click_1(sender As System.Object, e As System.EventArgs) Handles Button7.Click
        Dim TheFileLines As New List(Of String)
        Const FileAddress As String = "c:\as400sql\maquinas.txt"
        Dim line() As String = IO.File.ReadAllLines(FileAddress)
        TheFileLines.AddRange(System.IO.File.ReadAllLines(FileAddress))

        
        'If line >= TheFileLines.Count Then Exit Sub

        TheFileLines.RemoveAt(borrar)

        System.IO.File.WriteAllLines(FileAddress, TheFileLines.ToArray)
        MsgBox("Lpar Removed from list")
        CheckedListBox1.Items.Clear()
        'CheckedListBox1.SetItemCheckState(borrar, CheckState.Unchecked)
        Dim fichero As New System.IO.FileInfo(FileAddress)
        Dim sr443 As New System.IO.StreamReader(FileAddress)
        Dim VEO3 As String
        'sr44.ReadLine.FirstOrDefault()
        While Not sr443.EndOfStream
            VEO3 = sr443.ReadLine()
            CheckedListBox1.Items.Add(VEO3)
        End While
        sr443.Close()
        CheckedListBox1.Update()
        CheckedListBox1.Refresh()
    End Sub

    Private Sub Button8_Click(sender As System.Object, e As System.EventArgs) Handles Button88.Click
        Label11.Visible = True
        Label12.Visible = True
        Label11.Refresh()
        Label12.Refresh()

        ProgressBar1.Value = 0

        If TextBox4.Text = "" Or TextBox5.Text = "" Then
            MsgBox("You must complete the fields User and Password ", , "ASP")
            GoTo salir
        End If


        TextBox3.Refresh()
        Dim maquinaeip As String
        Dim maquina As String
        Dim ip As String
        Dim cantidadm As Integer
        Dim salida As String
        Dim todo As String
        Dim conector As String


        If marcaesta = 0 Then

            MsgBox("You must Select one Lpar ", , "SQL")
            GoTo salir
        End If



        ip = ip2



        userx = TextBox4.Text
        passx = TextBox5.Text

        Dim userpass As String
        userpass = "userid=" + userx + ";" + "password=" + passx + ";"


        Dim ejecutox As String
        Dim ejecutox2 As String

        Dim copia As String
        Dim copia2 As String
        userpass = "userid=" + userx + ";" + "password=" + passx + ";"

        conector = "DataSource=" + ip + ";" + " AllowUnsupportedChar=true" + ";"

        Dim thisConnection12 As New iDB2Connection(
              conector +
               userpass +
              "LibraryList=" + TextBox7.Text)
        thisConnection12.Open()



        'Dim thisCommand As New iDB2Command(TextBox6.Text, thisConnection12)
        'thisCommand.CommandTimeout = 0

        Dim thisReader As iDB2DataReader
        Try
            '    thisReader = thisCommand.ExecuteReader()
        Catch ex As Exception
            MsgBox("Verifique la sentencia SQL por favor" & vbCrLf & ex.Message)
            GoTo salir

        End Try
        Try
            Dim dt As New DataTable("consulta") ' le puse PTFW2 pero se puede llamar de cualquier nombre funciona igual
            'Dim dt As New DataTable("pirulo")
            Dim sFile As String = "C:\as400sql\SalidaCSV.csv"
            If File.Exists(sFile) = True Then 'Si el archivo existe, lo elimina antes
                My.Computer.FileSystem.DeleteFile(sFile, FileIO.UIOption.OnlyErrorDialogs, _
                                                  FileIO.RecycleOption.DeletePermanently, FileIO.UICancelOption.DoNothing)
            End If


            'Const Dat As String = ("C:\Registro.txt")
            ' GERENANDO EL ARCHIVO 
            Using f As New IO.StreamWriter(sFile, True)
                While thisReader.Read
                    Dim i1 As Integer
                    For i1 = 0 To thisReader.FieldCount - 1
                        Console.Write(thisReader.GetName(i1))
                        Console.Write(":" & vbTab)
                        'Console.WriteLine()
                        f.WriteLine(thisReader.GetValue(i1))
                    Next
                End While
            End Using


            thisConnection12.Close()
        Catch ex As Exception

            MsgBox("Tabla con datos invalidos " & vbCrLf & ex.Message)
        End Try

        ProgressBar1.Value = ProgressBar1.Value + 1
        ProgressBar1.Refresh()

salgo:
        Try
        Catch ex As Exception
            ProgressBar1.Value = ProgressBar1.Value + 1
            ProgressBar1.Refresh()


            '      sw.Close()
            ProgressBar1.Visible = False
            ProgressBar1.Refresh()
        End Try
        GoTo salir
salir:

        Label11.Visible = False
        Label12.Visible = False
        Label11.Refresh()
        Label12.Refresh()
    End Sub

    Private Sub Button8_Click_1(sender As System.Object, e As System.EventArgs)
        Dim conector As String
        Dim ip As String
        If TextBox4.Text = "" Or TextBox5.Text = "" Then
            MsgBox("You must complete the fields User and Password ", , "ASP")
            GoTo salir
        End If

        If marcaesta = 0 Then

            MsgBox("You must select one Lpar ", , "SQL")
            GoTo salir
        End If

        ip = ip2

        userx = TextBox4.Text
        passx = TextBox5.Text

        Dim userpass As String
        userpass = "userid=" + userx + ";" + "password=" + passx + ";"

        'Dim archivoauxiliar As String
        'Dim archivoauxiliar2 As String

        Dim ejecutox As String
        Dim ejecutox2 As String

        Dim copia As String
        Dim copia2 As String
        Dim copia22 As String



        userpass = "userid=" + userx + ";" + "password=" + passx + ";"

        conector = "DataSource=" + ip + ";" + " AllowUnsupportedChar=true" + ";"
        '            conector = "DataSource=" + ip + ";"

        Dim thisConnection12 As New iDB2Connection(
              conector +
               userpass +
              "LibraryList=" + "msops")
        thisConnection12.Open()

        'CRTPF      FILE(qtemp/paso) RCDLEN(256) + 
        'FILETYPE(*DATA) SIZE(*NOMAX)   

        ' CPYSPLF    FILE(QSYSPRT) TOFILE(qtemp/paso) +     
        '   JOB(&JOBNUM/&USERID/&JOBNAM) SPLNBR(*LAST) JOBSYSNAME(*CURRENT)  

        Dim archispool As String
        Dim jobnum As String
        Dim user As String
        Dim jobnombre As String

        'archispool = TextBox8.Text
        'jobnum = TextBox9.Text
        'user = TextBox10.Text
        'jobnombre = TextBox11.Text


        'copia = "CRTPF FILE(qtemp/paso) RCDLEN(256) FILETYPE(*DATA) SIZE(*NOMAX)"
        'copia2 = "CALL QSYS.QCMDEXC('" + copia + "', " + copia.Length.ToString("0000000000") + ".00000" + ")"

        copia = "CPYSPLF    FILE(" + archispool + ")" + " TOFILE(msops/ptfw2)" + " JOB(" + jobnum + "/" + user + "/" + jobnombre + ")" + " SPLNBR(*LAST) JOBSYSNAME(*CURRENT)"
        copia22 = "CALL QSYS.QCMDEXC('" + copia + "', " + copia.Length.ToString("0000000000") + ".00000" + ")"


        Try

            Dim strSelectStr = New IBM.Data.DB2.iSeries.iDB2Command(copia22, thisConnection12)
            strSelectStr.ExecuteNonQuery()
            strSelectStr.Dispose()

            Dim thisCommand As New iDB2Command("SELECT * FROM msops.ptfw2", thisConnection12)

            Dim thisReader As iDB2DataReader
            thisReader = thisCommand.ExecuteReader()
            Dim dt As New DataTable("ptfw2")
            dt.Load(thisReader)
            DataGridView1.DataSource = dt

            'intento mandarlo a pdf ------------------------------------------------------------
            ' ReportViewer1.LocalReport.DataSources.Clear()
            ' 'Dim dt As New DataTable

            'Dim rprtDTSource As Microsoft.Reporting.WinForms.ReportDataSource = New Microsoft.Reporting.WinForms.ReportDataSource(dt.TableName, dt)
            'ReportViewer1.LocalReport.DataSources.Add(rprtDTSource)
            'ReportViewer1.RefreshReport()


            'Dim pdfContent As Byte() = ReportViewer1.LocalReport.Render("PDF", Nothing, Nothing, Nothing, Nothing, Nothing, Nothing)
            'Dim pdfContent As Byte() = DataGridView1.DataSource("PDF", Nothing, Nothing, Nothing, Nothing, Nothing, Nothing)

            'Creatr PDF file on disk
            'Dim pdfPath As String = "C:\as400sql\report.pdf"
            'Dim pdfFile As New System.IO.FileStream(pdfPath, System.IO.FileMode.Create)
            'pdfFile.Write(pdfContent, 0, pdfContent.Length)
            ' pdfFile.Close()
            '-----------------------------------------------------------------------------------

        Catch ex As Exception

            MsgBox("Chequear los  datos cargados son erroneos " & vbCrLf & ex.Message)
        End Try
salir:
    End Sub

    Private Sub Button9_Click(sender As System.Object, e As System.EventArgs)

    End Sub

    Private Sub Button8_Click_2(sender As System.Object, e As System.EventArgs) Handles Button8.Click
        'MsgBox("Este proceso puede demorar algunos minutos...presione aceptar", , "Exporto")
        ' Label6.Visible = True
        ' Label6.Refresh()
        ' aca va el codigo ---------------------------------------

        Try
            Dim iExp As New funciones
            iExp.DataTableToExcel(CType(Me.DataGridView1.DataSource, DataTable))

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


        ' --------------------------------------------------------
        'Label6.Visible = False
    End Sub

    Private Sub Button5_Click_2(sender As System.Object, e As System.EventArgs) Handles Button5.Click

        If DataGridView1.RowCount = 0 Then
            MessageBox.Show("El datagridview esta vacio")
        Else
            If Directory.Exists("C:\as400sql") = False Then ' si no existe la carpeta se crea
                Directory.CreateDirectory("C:\as400sql")
            End If
            Dim sFile As String = "C:\as400sql\Salidatexto.txt"
            If File.Exists(sFile) = True Then 'Si el archivo existe, lo elimina antes
                My.Computer.FileSystem.DeleteFile(sFile, FileIO.UIOption.OnlyErrorDialogs, _
                                                  FileIO.RecycleOption.DeletePermanently, FileIO.UICancelOption.DoNothing)
            End If


            'Const Dat As String = ("C:\Registro.txt")
            ' GERENANDO EL ARCHIVO 
            Using f As New IO.StreamWriter(sFile, True)

                ' AGREGANDO LAS COLUMNAS 
                Dim col As String = ""
                ' AGREGANDO LAS FILAS 
                Dim row As String = ""
                Dim i As Integer = 0
                For Each r As DataGridViewRow In DataGridView1.Rows
                    For Each c As DataGridViewColumn In DataGridView1.Columns

                        'row = row & "'" & Convert.ToString(r.Cells(c.HeaderText).Value) & vbTab
                        row = row & Convert.ToString(r.Cells(c.HeaderText).Value) & vbTab
                    Next
                    If i < DataGridView1.Rows.Count - 1 Then row &= Environment.NewLine
                Next

                'AGREGANDO LA INFORMACION 
                f.WriteLine(row)
                MessageBox.Show("El archivo SALIDATEXTO.txt ha sido creado en la carpeta C:\as400sql ")
            End Using
        End If
    End Sub

    Private Sub Button4_Click_3(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        If DataGridView1.RowCount = 0 Then
            MessageBox.Show("El datagridview esta vacio")
        Else
            If Directory.Exists("C:\as400sql") = False Then ' si no existe la carpeta se crea
                Directory.CreateDirectory("C:\as400sql")
            End If
            Dim sFile As String = "C:\as400sql\SalidaCSV.csv"
            If File.Exists(sFile) = True Then 'Si el archivo existe, lo elimina antes
                My.Computer.FileSystem.DeleteFile(sFile, FileIO.UIOption.OnlyErrorDialogs, _
                                                  FileIO.RecycleOption.DeletePermanently, FileIO.UICancelOption.DoNothing)
            End If


            'Const Dat As String = ("C:\Registro.txt")
            ' GERENANDO EL ARCHIVO 
            Using f As New IO.StreamWriter(sFile, True)

                ' AGREGANDO LAS COLUMNAS 
                Dim col As String = ""
                ' AGREGANDO LAS FILAS 
                Dim row As String = ""
                Dim i As Integer = 0
                For Each r As DataGridViewRow In DataGridView1.Rows
                    For Each c As DataGridViewColumn In DataGridView1.Columns

                        'row = row & "'" & Convert.ToString(r.Cells(c.HeaderText).Value) & vbTab
                        row = row & Convert.ToString(r.Cells(c.HeaderText).Value) & ","
                    Next
                    If i < DataGridView1.Rows.Count - 1 Then row &= Environment.NewLine
                Next

                'AGREGANDO LA INFORMACION 
                f.WriteLine(row)
                MessageBox.Show("El archivo SALIDACSV.csv ha sido creado en la carpeta C:\as400sql ")
            End Using
        End If
    End Sub

    Private Sub Button6_Click_3(sender As System.Object, e As System.EventArgs) Handles Button6.Click

        Chart1.Visible = False
        Chart2.Visible = False
        Label30.Visible = False
        Label31.Visible = False
        Label32.Visible = False
        Label30.Refresh()
        Label31.Refresh()
        Label32.Refresh()
        Dim conector As String
        Dim ip As String
        If TextBox4.Text = "" Or TextBox5.Text = "" Then
            MsgBox("You must complete the fields User and Password ", , "ASP")
            GoTo salir
        End If

        If marcaesta = 0 Then

            MsgBox("You must select one Lpar ", , "SQL")
            GoTo salir
        End If

        ip = ip2

        userx = TextBox4.Text
        passx = TextBox5.Text

        Dim userpass As String
        userpass = "userid=" + userx + ";" + "password=" + passx + ";"


        Dim ejecutox As String
        Dim ejecutox2 As String

        Dim copia As String
        Dim copia2 As String
        Dim copia22 As String



        userpass = "userid=" + userx + ";" + "password=" + passx + ";"

        conector = "DataSource=" + ip + ";" + " AllowUnsupportedChar=true" + ";"

        Label11.Enabled = True
        Label11.Visible = True

        Label11.Refresh()
        Try
            Dim thisConnection12 As New iDB2Connection(
                  conector +
                   userpass +
                  "LibraryList=" + "isysmodobj")
            thisConnection12.Open()



            Dim archispool As String
            Dim jobnum As String
            Dim user As String
            Dim jobnombre As String
            Dim fecha1 As String
            Dim fecha2 As String


            fecha1 = datetimepicker1.Value.ToString("yyyy-MM-dd")
            fecha2 = datetimepicker2.Value.ToString("yyyy-MM-dd")


            'Try


            'Dim thisCommand As New iDB2Command("SELECT system_table_schema as Library, system_table_name as Archivo, Fecha, Data_size_GB, Fecha01, Data_siz0001, Aument_GB FROM isysmodobj.unionasphi where aument_gb >0 and  fecha >= '" & fecha1 & "' AND fecha <='" & fecha2 & "'  ", thisConnection12)
            Dim thisCommand As New iDB2Command("SELECT system_table_schema as Library, system_table_name as Archivo, char(Fecha,iso) as Fecha,  Data_size_GB, Char(Fecha01,iso) as Fecha01, Data_siz0001, Aument_GB FROM isysmodobj.unionasphi where aument_gb >0 and  fecha >= '" & fecha1 & "' AND fecha <='" & fecha2 & "' order by system_table_schema,system_table_name,Fecha ", thisConnection12)

            Dim thisReader As iDB2DataReader
            thisReader = thisCommand.ExecuteReader()
            Dim dt As New DataTable("unionasphi")
            dt.Load(thisReader)
            DataGridView1.DataSource = dt
            Label11.Visible = False
            Label11.Refresh()

            If DataGridView1.Rows.Count = 1 Then
                MsgBox("There are not  files found with greater variations to 1Gb ", , "Increase Files ")
            End If


            '-----------------------------------------------------------------------------------
            '-----------------------------------------------------------------------------------

            ' pruebo el grafico de chart 

            Label32.Visible = False
            Label32.Refresh()
            Label30.Visible = True
            Label31.Visible = False
            Label30.Text = "Growth Files"
            Label30.Refresh()
            Chart2.Visible = False                                  'cambio a chart1
            Chart1.Visible = True                                   'cambio a chart2
            Chart1.Series("File").XValueMember = "Archivo"          'cambio a chart2
            Chart1.Series("File").YValueMembers = "Aument_GB"       'cambio a chart2
            Chart1.Series("File").Points.AddXY("Archivo", "Aument_GB") 'cambio a chart2


            Chart1.DataSource = dt                                  'cambio a chart2

            '-----------------------------------------------------------
            'prueba cambiar el chrttype 



            Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.StackedColumn  'cambio a chart2

            '------------------------------------------------------------------
            '------------------------------------------------------------------







        Catch ex As Exception

            MsgBox("Check, the loaded data is wrong  " & vbCrLf & ex.Message)
        End Try
salir:
    End Sub

    Private Sub Button9_Click_1(sender As System.Object, e As System.EventArgs) Handles Button9.Click
        Chart1.Visible = False
        Chart2.Visible = False
        Label30.Visible = False
        Label31.Visible = False
        Label32.Visible = False
        Label30.Refresh()
        Label31.Refresh()
        Label32.Refresh()

        Dim conector As String
        Dim ip As String
        If TextBox4.Text = "" Or TextBox5.Text = "" Then
            MsgBox("You must complete the fields User and Password ", , "ASP")
            GoTo salir
        End If

        If marcaesta = 0 Then

            MsgBox("You must select one Lpar ", , "SQL")
            GoTo salir
        End If

        ip = ip2

        userx = TextBox4.Text
        passx = TextBox5.Text

        Dim userpass As String
        userpass = "userid=" + userx + ";" + "password=" + passx + ";"


        Dim ejecutox As String
        Dim ejecutox2 As String

        Dim copia As String
        Dim copia2 As String
        Dim copia22 As String



        userpass = "userid=" + userx + ";" + "password=" + passx + ";"

        conector = "DataSource=" + ip + ";" + " AllowUnsupportedChar=true" + ";"

        Label11.Enabled = True
        Label11.Visible = True

        Label11.Refresh()

        Try
            Dim thisConnection12 As New iDB2Connection(
                  conector +
                   userpass +
                  "LibraryList=" + "isysmodobj")
            thisConnection12.Open()


            Dim archispool As String
            Dim jobnum As String
            Dim user As String
            Dim jobnombre As String
            Dim fecha1 As String
            Dim fecha2 As String
            fecha1 = DateTimePicker3.Value.ToString("yyyy-MM-dd")
            ' fecha2 = DateTimePicker4.Value.ToString("yyyy-MM-dd")


            'Try



            Dim thisCommand As New iDB2Command("SELECT system_table_schema as Library, system_table_name as Archivo, Fecha, Data_size_GB, Fecha01, Data_siz0001, Aument_GB FROM isysmodobj.unionasphi where   fecha = '" & fecha1 & "'  ORDER BY DATA_SIZ0001 desc, system_table_schema, system_table_name ", thisConnection12)

            Dim thisReader As iDB2DataReader
            thisReader = thisCommand.ExecuteReader()
            Dim dt As New DataTable("unionasphi")
            dt.Load(thisReader)
            DataGridView1.DataSource = dt
            Label11.Visible = False
            Label11.Refresh()

            If DataGridView1.Rows.Count = 1 Then
                MsgBox(" No files were found between selected dates ", , "File Growth")
            End If

            '-----------------------------------------------------------------------------------
            '-----------------------------------------------------------------------------------

            ' pruebo el grafico de chart 

            Label32.Visible = False
            Label32.Refresh()
            Label30.Visible = True
            Label31.Visible = False
            Label30.Text = "Growth Files"
            Label30.Refresh()
            Chart2.Visible = False
            Chart1.Visible = True
            Chart1.Series("File").XValueMember = "Archivo"
            Chart1.Series("File").YValueMembers = "Data_size_GB"
            Chart1.Series("File").Points.AddXY("Archivo", "Data_size_GB")


            Chart1.DataSource = dt

            '-----------------------------------------------------------
            'prueba cambiar el chrttype 


            Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Doughnut

            '------------------------------------------------------------------
            '------------------------------------------------------------------





        Catch ex As Exception

            MsgBox("Check, the loaded data is wrong " & vbCrLf & ex.Message)
        End Try
salir:
    End Sub

    Private Sub Button11_Click(sender As System.Object, e As System.EventArgs) Handles Button11.Click
        Dim conector As String
        Dim ip As String
        If TextBox4.Text = "" Or TextBox5.Text = "" Then
            MsgBox("You must complete the fields User and Password ", , "ASP")
            GoTo salir
        End If

        If marcaesta = 0 Then

            MsgBox("You must select one Lpar ", , "SQL")
            GoTo salir
        End If

        ip = ip2

        userx = TextBox4.Text
        passx = TextBox5.Text

        Dim userpass As String
        userpass = "userid=" + userx + ";" + "password=" + passx + ";"


        Dim ejecutox As String
        Dim ejecutox2 As String

        Dim copia As String
        Dim copia2 As String
        Dim copia22 As String



        userpass = "userid=" + userx + ";" + "password=" + passx + ";"

        conector = "DataSource=" + ip + ";" + " AllowUnsupportedChar=true" + ";"

        Label11.Enabled = True
        Label11.Visible = True

        Label11.Refresh()

        Try
            Dim thisConnection12 As New iDB2Connection(
                  conector +
                   userpass +
                  "LibraryList=" + "isysmodobj")
            thisConnection12.Open()


            Dim archispool As String
            Dim jobnum As String
            Dim user As String
            Dim jobnombre As String
            Dim fecha1 As String
            'Dim fecha2 As String


            fecha1 = DateTimePicker7.Value.ToString("yyyy-MM-dd")
            'fecha2 = DateTimePicker8.Value.ToString("yyyy-MM-dd")


            'Try



            Dim thisCommand As New iDB2Command("SELECT BIBLIOTECA, ARCHIVO, NUM_FILAS, NUM_REG_DEL, DATE_EXTRAC, SIZE_GB, int(NUM_FILAS*SIZE_GB/(NUM_FILAS+NUM_REG_DEL)) AS SI_REORG_GB, int(SIZE_GB-(NUM_FILAS*SIZE_GB/(NUM_FILAS+NUM_REG_DEL))) AS RECUPERO_GB  FROM isysmodobj.histasp  where num_reg_del >1 and SIZE_GB-(NUM_FILAS*SIZE_GB/(NUM_FILAS+NUM_REG_DEL)) > 1 and  date_extrac = '" & fecha1 & "'  order by num_reg_del desc fetch first 20 rows only ", thisConnection12)

            Dim thisReader As iDB2DataReader
            thisReader = thisCommand.ExecuteReader()
            Dim dt As New DataTable("histasp")
            dt.Load(thisReader)
            DataGridView2.DataSource = dt
            Label11.Visible = False
            Label11.Refresh()

            ' pruebo el grafico de chart -------------------------------
            ' Chart1.Series("Archivo").Points.AddXY("ARCHIVO", "NUM_REG_DEL")
            Label32.Visible = False
            Label32.Refresh()
            Label30.Visible = True
            Label31.Visible = False
            Label30.Text = "Deleted Records"
            Label30.Refresh()
            Chart2.Visible = False
            Chart1.Visible = True
            Chart1.Series("File").XValueMember = "ARCHIVO"
            Chart1.Series("File").YValueMembers = "NUM_REG_DEL"
            Chart1.Series("File").Points.AddXY("ARCHIVO", "NUM_REG_DEL")


            Chart1.DataSource = dt

            '-----------------------------------------------------------
            'prueba cambiar el chrttype ---------------------------------------


            Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Pie
            'Chart1.Series.ch()
            '------------------------------------------------------------------

            '-----------------------------------------------------------------------------------

        Catch ex As Exception

            MsgBox("Check, the loaded data is wrong " & vbCrLf & ex.Message)
        End Try
salir:
    End Sub

    Private Sub Button14_Click(sender As System.Object, e As System.EventArgs) Handles Button14.Click
        'MsgBox("Este proceso puede demorar algunos minutos...presione aceptar", , "Exporto")
        ' Label6.Visible = True
        ' Label6.Refresh()
        ' aca va el codigo ---------------------------------------

        Try
            Dim iExp As New funciones
            iExp.DataTableToExcel(CType(Me.DataGridView2.DataSource, DataTable))

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


        ' --------------------------------------------------------
        'Label6.Visible = False
    End Sub

    Private Sub Button13_Click(sender As System.Object, e As System.EventArgs) Handles Button13.Click
        If DataGridView2.RowCount = 0 Then
            MessageBox.Show("El datagridview esta vacio")
        Else
            If Directory.Exists("C:\as400sql") = False Then ' si no existe la carpeta se crea
                Directory.CreateDirectory("C:\as400sql")
            End If
            Dim sFile As String = "C:\as400sql\Salidatexto.txt"
            If File.Exists(sFile) = True Then 'Si el archivo existe, lo elimina antes
                My.Computer.FileSystem.DeleteFile(sFile, FileIO.UIOption.OnlyErrorDialogs, _
                                                  FileIO.RecycleOption.DeletePermanently, FileIO.UICancelOption.DoNothing)
            End If


            'Const Dat As String = ("C:\Registro.txt")
            ' GERENANDO EL ARCHIVO 
            Using f As New IO.StreamWriter(sFile, True)

                ' AGREGANDO LAS COLUMNAS 
                Dim col As String = ""
                ' AGREGANDO LAS FILAS 
                Dim row As String = ""
                Dim i As Integer = 0
                For Each r As DataGridViewRow In DataGridView2.Rows
                    For Each c As DataGridViewColumn In DataGridView2.Columns

                        'row = row & "'" & Convert.ToString(r.Cells(c.HeaderText).Value) & vbTab
                        row = row & Convert.ToString(r.Cells(c.HeaderText).Value) & vbTab
                    Next
                    If i < DataGridView2.Rows.Count - 1 Then row &= Environment.NewLine
                Next

                'AGREGANDO LA INFORMACION 
                f.WriteLine(row)
                MessageBox.Show("El archivo SALIDATEXTO.txt ha sido creado en la carpeta C:\as400sql ")
            End Using
        End If
    End Sub

    Private Sub Button12_Click(sender As System.Object, e As System.EventArgs) Handles Button12.Click
        If DataGridView2.RowCount = 0 Then
            MessageBox.Show("El datagridview esta vacio")
        Else
            If Directory.Exists("C:\as400sql") = False Then ' si no existe la carpeta se crea
                Directory.CreateDirectory("C:\as400sql")
            End If
            Dim sFile As String = "C:\as400sql\SalidaCSV.csv"
            If File.Exists(sFile) = True Then 'Si el archivo existe, lo elimina antes
                My.Computer.FileSystem.DeleteFile(sFile, FileIO.UIOption.OnlyErrorDialogs, _
                                                  FileIO.RecycleOption.DeletePermanently, FileIO.UICancelOption.DoNothing)
            End If


            'Const Dat As String = ("C:\Registro.txt")
            ' GERENANDO EL ARCHIVO 
            Using f As New IO.StreamWriter(sFile, True)

                ' AGREGANDO LAS COLUMNAS 
                Dim col As String = ""
                ' AGREGANDO LAS FILAS 
                Dim row As String = ""
                Dim i As Integer = 0
                For Each r As DataGridViewRow In DataGridView2.Rows
                    For Each c As DataGridViewColumn In DataGridView2.Columns

                        'row = row & "'" & Convert.ToString(r.Cells(c.HeaderText).Value) & vbTab
                        row = row & Convert.ToString(r.Cells(c.HeaderText).Value) & ","
                    Next
                    If i < DataGridView2.Rows.Count - 1 Then row &= Environment.NewLine
                Next

                'AGREGANDO LA INFORMACION 
                f.WriteLine(row)
                MessageBox.Show("El archivo SALIDACSV.csv ha sido creado en la carpeta C:\as400sql ")
            End Using
        End If
    End Sub

    Private Sub Button10_Click(sender As System.Object, e As System.EventArgs) Handles Button10.Click
        Dim conector As String
        Dim ip As String
        If TextBox4.Text = "" Or TextBox5.Text = "" Then
            MsgBox("You must complete the fields User and Password ", , "ASP")
            GoTo salir
        End If

        If marcaesta = 0 Then

            MsgBox("You must select one Lpar ", , "SQL")
            GoTo salir
        End If

        ip = ip2

        userx = TextBox4.Text
        passx = TextBox5.Text

        Dim userpass As String
        userpass = "userid=" + userx + ";" + "password=" + passx + ";"


        Dim ejecutox As String
        Dim ejecutox2 As String

        Dim copia As String
        Dim copia2 As String
        Dim copia22 As String



        userpass = "userid=" + userx + ";" + "password=" + passx + ";"

        conector = "DataSource=" + ip + ";" + " AllowUnsupportedChar=true" + ";"

        Label11.Enabled = True
        Label11.Visible = True

        Label11.Refresh()

        Try
            Dim thisConnection12 As New iDB2Connection(
                  conector +
                   userpass +
                  "LibraryList=" + "isysmodobj")
            thisConnection12.Open()


            Dim archispool As String
            Dim jobnum As String
            Dim user As String
            Dim jobnombre As String
            Dim fecha1 As String
            'Dim fecha2 As String


            fecha1 = DateTimePicker5.Value.ToString("yyyy-MM-dd")
            'fecha2 = DateTimePicker6.Value.ToString("yyyy-MM-dd")


            'Try



            Dim thisCommand As New iDB2Command("SELECT * FROM isysmodobj.histasp where num_filas >0 and  date_extrac = '" & fecha1 & "'  order by num_filas desc fetch first 20 rows only ", thisConnection12)

            Dim thisReader As iDB2DataReader
            thisReader = thisCommand.ExecuteReader()
            Dim dt As New DataTable("histasp")
            dt.Load(thisReader)
            DataGridView2.DataSource = dt
            Label11.Visible = False
            Label11.Refresh()

            ' pruebo el grafico de chart -------------------------------
            ' Chart1.Series("Archivo").Points.AddXY("ARCHIVO", "NUM_REG_DEL")
            Chart2.Visible = False
            Chart1.Visible = True
            Label32.Visible = False
            Label32.Refresh()
            Label30.Visible = True
            Label30.Text = "Active Records"
            Label30.Refresh()
            Label31.Visible = False
            Chart1.Series("File").XValueMember = "ARCHIVO"
            Chart1.Series("File").YValueMembers = "NUM_FILAS"
            Chart1.Series("File").Points.AddXY("ARCHIVO", "NUM_FILAS")

            'prueba cambiar el chrttype ---------------------------------------


            Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Pie
            'Chart1.Series.ch()
            '------------------------------------------------------------------
            Chart1.DataSource = dt

            '-----------------------------------------------------------


            '-----------------------------------------------------------------------------------

        Catch ex As Exception

            MsgBox("Check, the loaded data is wrong " & vbCrLf & ex.Message)
        End Try
salir:
    End Sub

    Private Sub Button19_Click(sender As System.Object, e As System.EventArgs) Handles Button19.Click
        'MsgBox("Este proceso puede demorar algunos minutos...presione aceptar", , "Exporto")
        ' Label6.Visible = True
        ' Label6.Refresh()
        ' aca va el codigo ---------------------------------------

        Try
            Dim iExp As New funciones
            iExp.DataTableToExcel(CType(Me.DataGridView3.DataSource, DataTable))

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


        ' --------------------------------------------------------
        'Label6.Visible = False
    End Sub

    Private Sub Button18_Click(sender As System.Object, e As System.EventArgs) Handles Button18.Click
        If DataGridView3.RowCount = 0 Then
            MessageBox.Show("El datagridview esta vacio")
        Else
            If Directory.Exists("C:\as400sql") = False Then ' si no existe la carpeta se crea
                Directory.CreateDirectory("C:\as400sql")
            End If
            Dim sFile As String = "C:\as400sql\Salidatexto.txt"
            If File.Exists(sFile) = True Then 'Si el archivo existe, lo elimina antes
                My.Computer.FileSystem.DeleteFile(sFile, FileIO.UIOption.OnlyErrorDialogs, _
                                                  FileIO.RecycleOption.DeletePermanently, FileIO.UICancelOption.DoNothing)
            End If


            'Const Dat As String = ("C:\Registro.txt")
            ' GERENANDO EL ARCHIVO 
            Using f As New IO.StreamWriter(sFile, True)

                ' AGREGANDO LAS COLUMNAS 
                Dim col As String = ""
                ' AGREGANDO LAS FILAS 
                Dim row As String = ""
                Dim i As Integer = 0
                For Each r As DataGridViewRow In DataGridView3.Rows
                    For Each c As DataGridViewColumn In DataGridView3.Columns

                        'row = row & "'" & Convert.ToString(r.Cells(c.HeaderText).Value) & vbTab
                        row = row & Convert.ToString(r.Cells(c.HeaderText).Value) & vbTab
                    Next
                    If i < DataGridView3.Rows.Count - 1 Then row &= Environment.NewLine
                Next

                'AGREGANDO LA INFORMACION 
                f.WriteLine(row)
                MessageBox.Show("El archivo SALIDATEXTO.txt ha sido creado en la carpeta C:\as400sql ")
            End Using
        End If
    End Sub

    Private Sub Button17_Click(sender As System.Object, e As System.EventArgs) Handles Button17.Click
        If DataGridView3.RowCount = 0 Then
            MessageBox.Show("El datagridview esta vacio")
        Else
            If Directory.Exists("C:\as400sql") = False Then ' si no existe la carpeta se crea
                Directory.CreateDirectory("C:\as400sql")
            End If
            Dim sFile As String = "C:\as400sql\SalidaCSV.csv"
            If File.Exists(sFile) = True Then 'Si el archivo existe, lo elimina antes
                My.Computer.FileSystem.DeleteFile(sFile, FileIO.UIOption.OnlyErrorDialogs, _
                                                  FileIO.RecycleOption.DeletePermanently, FileIO.UICancelOption.DoNothing)
            End If


            'Const Dat As String = ("C:\Registro.txt")
            ' GERENANDO EL ARCHIVO 
            Using f As New IO.StreamWriter(sFile, True)

                ' AGREGANDO LAS COLUMNAS 
                Dim col As String = ""
                ' AGREGANDO LAS FILAS 
                Dim row As String = ""
                Dim i As Integer = 0
                For Each r As DataGridViewRow In DataGridView3.Rows
                    For Each c As DataGridViewColumn In DataGridView3.Columns

                        'row = row & "'" & Convert.ToString(r.Cells(c.HeaderText).Value) & vbTab
                        row = row & Convert.ToString(r.Cells(c.HeaderText).Value) & ","
                    Next
                    If i < DataGridView3.Rows.Count - 1 Then row &= Environment.NewLine
                Next

                'AGREGANDO LA INFORMACION 
                f.WriteLine(row)
                MessageBox.Show("El archivo SALIDACSV.csv ha sido creado en la carpeta C:\as400sql ")
            End Using
        End If
    End Sub

    Private Sub Button16_Click(sender As System.Object, e As System.EventArgs) Handles Button16.Click
        Dim conector As String
        Dim ip As String
        If TextBox4.Text = "" Or TextBox5.Text = "" Then
            MsgBox("You must complete the fields User and Password ", , "ASP")
            GoTo salir
        End If

        If marcaesta = 0 Then

            MsgBox("You must select one lpar ", , "SQL")
            GoTo salir
        End If

        ip = ip2

        userx = TextBox4.Text
        passx = TextBox5.Text

        Dim userpass As String
        userpass = "userid=" + userx + ";" + "password=" + passx + ";"


        Dim ejecutox As String
        Dim ejecutox2 As String

        Dim copia As String
        Dim copia2 As String
        Dim copia22 As String



        userpass = "userid=" + userx + ";" + "password=" + passx + ";"

        conector = "DataSource=" + ip + ";" + " AllowUnsupportedChar=true" + ";"

        Label11.Enabled = True
        Label11.Visible = True

        Label11.Refresh()

        Try
            Dim thisConnection12 As New iDB2Connection(
                  conector +
                   userpass +
                  "LibraryList=" + "isysmodobj")
            thisConnection12.Open()


            Dim archispool As String
            Dim jobnum As String
            Dim user As String
            Dim jobnombre As String
            Dim fecha1 As String
            Dim fecha2 As String
            Dim biblioteca As String
            Dim archivo As String


            ' fecha1 = DateTimePicker7.Value.ToString("yyyy-MM-dd")
            ' fecha2 = DateTimePicker8.Value.ToString("yyyy-MM-dd")
            biblioteca = TextBox6.Text
            archivo = TextBox8.Text

            fecha1 = DateTimePicker8.Value.ToString("yyyy-MM-dd")
            fecha2 = DateTimePicker6.Value.ToString("yyyy-MM-dd")

            'Try



            Dim thisCommand As New iDB2Command("SELECT biblioteca, archivo, num_filas, num_reg_del, char(date_extrac,iso) as date_extrac, size_gb FROM isysmodobj.histasp where biblioteca= '" & biblioteca & "' AND archivo ='" & archivo & "' and  date_extrac >= '" & fecha1 & "' AND date_extrac <='" & fecha2 & "'  order by date_extrac asc ", thisConnection12)

            Dim thisReader As iDB2DataReader
            thisReader = thisCommand.ExecuteReader()
            Dim dt As New DataTable("histasp")
            dt.Load(thisReader)
            DataGridView3.DataSource = dt
            Label11.Visible = False
            Label11.Refresh()

            Chart1.Visible = False
            Chart2.Visible = True
            Label30.Visible = False
            Label31.Visible = True
            Label31.Text = "Files Growth"
            Label31.Refresh()
            Chart2.Series("Objects").XValueMember = "date_extrac"
            ' Chart2.Series("Archivo").XValueType = vbDate
            Chart2.Series("Objects").YValueMembers = "size_gb"
            Chart2.Series("Objects").Points.AddXY("date_extrac", "size_gb")

            Label32.Visible = True
            Label32.Text = TextBox8.Text
            Label32.Refresh()


            Chart2.DataSource = dt
            Chart2.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Line
            '-----------------------------------------------------------------------------------

        Catch ex As Exception

            MsgBox("Check, the loaded data is wrong " & vbCrLf & ex.Message)
        End Try
salir:
    End Sub

    Private Sub Button15_Click(sender As System.Object, e As System.EventArgs) Handles Button15.Click
        Dim conector As String
        Dim ip As String
        If TextBox4.Text = "" Or TextBox5.Text = "" Then
            MsgBox("You must complete the fields User and Password ", , "ASP")
            GoTo salir
        End If

        If marcaesta = 0 Then

            MsgBox("You must select one Lpar ", , "SQL")
            GoTo salir
        End If

        ip = ip2

        userx = TextBox4.Text
        passx = TextBox5.Text

        Dim userpass As String
        userpass = "userid=" + userx + ";" + "password=" + passx + ";"


        Dim ejecutox As String
        Dim ejecutox2 As String

        Dim copia As String
        Dim copia2 As String
        Dim copia22 As String



        userpass = "userid=" + userx + ";" + "password=" + passx + ";"

        conector = "DataSource=" + ip + ";" + " AllowUnsupportedChar=true" + ";"

        Label11.Enabled = True
        Label11.Visible = True

        Label11.Refresh()

        Try
            Dim thisConnection12 As New iDB2Connection(
                  conector +
                   userpass +
                  "LibraryList=" + "isysmodobj")
            thisConnection12.Open()


            Dim archispool As String
            Dim jobnum As String
            Dim user As String
            Dim jobnombre As String
            Dim fecha1 As String
            Dim fecha2 As String
            Dim biblioteca As String
            Dim archivo As String


            ' fecha1 = DateTimePicker7.Value.ToString("yyyy-MM-dd")
            ' fecha2 = DateTimePicker8.Value.ToString("yyyy-MM-dd")
            biblioteca = TextBox9.Text
            archivo = TextBox10.Text
            fecha1 = DateTimePicker10.Value.ToString("yyyy-MM-dd")
            fecha2 = DateTimePicker9.Value.ToString("yyyy-MM-dd")

            'Try



            Dim thisCommand As New iDB2Command("SELECT system_table_schema as Library, system_table_name as ARCHIVO, char(Fecha,iso) as Fecha, Data_size_GB, char(Fecha01,iso) as Fecha01, Data_siz0001 as Data_size_GB_2 , Aument_GB  FROM isysmodobj.unionasphi where system_table_schema= '" & biblioteca & "' AND system_table_name ='" & archivo & "' and  fecha >= '" & fecha1 & "' AND fecha <='" & fecha2 & "' order by fecha asc ", thisConnection12)

            Dim thisReader As iDB2DataReader
            thisReader = thisCommand.ExecuteReader()
            Dim dt As New DataTable("unionasphi")
            dt.Load(thisReader)
            DataGridView3.DataSource = dt
            Label11.Visible = False
            Label11.Refresh()

            '-----------------------------------------------------------------------------------

            ' pruebo el grafico de chart -------------------------------

            ' DataVisualization.Charting.SeriesChartType.Line()
            Chart1.Visible = False
            Chart2.Visible = True
            Label30.Visible = False
            Label31.Visible = True
            Label31.Text = "Files Growth"
            Label31.Refresh()
            Chart2.Series("Objects").XValueMember = "Fecha01"
            ' Chart2.Series("Archivo").XValueType = vbDate
            Chart2.Series("Objects").YValueMembers = "Data_size_GB_2"
            Chart2.Series("Objects").Points.AddXY("Fecha01", "Data_size_GB_2")

            Label32.Visible = True
            Label32.Text = TextBox10.Text
            Label32.Refresh()


            Chart2.DataSource = dt

            '-----------------------------------------------------------



        Catch ex As Exception

            MsgBox("Incorrect...Check the data please " & vbCrLf & ex.Message)
        End Try
salir:

    End Sub

    Private Sub SalirToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SalirToolStripMenuItem.Click
        End

    End Sub

    Private Sub DataGridView1_CellContentClick_1(sender As System.Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        Chart1.Size = New System.Drawing.Size(750, 490)
        Chart1.Location = New System.Drawing.Point(200, 76)

        Chart2.Size = New System.Drawing.Size(750, 490)
        Chart2.Location = New System.Drawing.Point(200, 76)


    End Sub

    Private Sub Button20_Click(sender As System.Object, e As System.EventArgs) Handles Button20.Click
        Chart1.Size = New System.Drawing.Size(341, 153)
        Chart1.Location = New System.Drawing.Point(631, 27)

        Chart2.Size = New System.Drawing.Size(341, 153)
        Chart2.Location = New System.Drawing.Point(631, 27)

    End Sub

    Private Sub Label5_Click(sender As System.Object, e As System.EventArgs) Handles Label5.Click

    End Sub

    Private Sub Button21_Click(sender As System.Object, e As System.EventArgs) Handles Button21.Click

        Chart1.Visible = False
        Chart2.Visible = False
        Label30.Visible = False
        Label31.Visible = False
        Label32.Visible = False
        Label30.Refresh()
        Label31.Refresh()
        Label32.Refresh()
        Dim conector As String
        Dim ip As String
        If TextBox4.Text = "" Or TextBox5.Text = "" Then
            MsgBox("You must complete the fields User and Password ", , "ASP")
            GoTo salir
        End If

        If marcaesta = 0 Then

            MsgBox("You must select one Lpar ", , "SQL")
            GoTo salir
        End If

        ip = ip2

        userx = TextBox4.Text
        passx = TextBox5.Text

        Dim userpass As String
        userpass = "userid=" + userx + ";" + "password=" + passx + ";"


        Dim ejecutox As String
        Dim ejecutox2 As String

        Dim copia As String
        Dim copia2 As String
        Dim copia22 As String



        userpass = "userid=" + userx + ";" + "password=" + passx + ";"

        conector = "DataSource=" + ip + ";" + " AllowUnsupportedChar=true" + ";"

        Label11.Enabled = True
        Label11.Visible = True

        Label11.Refresh()
        Try
            Dim thisConnection12 As New iDB2Connection(
                  conector +
                   userpass +
                  "LibraryList=" + "isysmodobj")
            thisConnection12.Open()



            Dim archispool As String
            Dim jobnum As String
            Dim user As String
            Dim jobnombre As String
            Dim fecha1 As String
            Dim fecha2 As String


            fecha1 = DateTimePicker11.Value.ToString("yyyy-MM-dd")
            fecha2 = DateTimePicker4.Value.ToString("yyyy-MM-dd")


            'Try


            'Dim thisCommand As New iDB2Command("SELECT system_table_schema as Library, system_table_name as Archivo, Fecha, Data_size_GB, Fecha01, Data_siz0001, Aument_GB FROM isysmodobj.unionasphi where aument_gb >0 and  fecha >= '" & fecha1 & "' AND fecha <='" & fecha2 & "'  ", thisConnection12)
            Dim thisCommand As New iDB2Command("SELECT system_table_schema as Library, system_table_name as Archivo, char(Fecha,iso) as Fecha,  Data_size_GB, Char(Fecha01,iso) as Fecha01, Data_siz0001, Aument_GB as Decrease_GB FROM isysmodobj.unionasphi where aument_gb < 0 and  fecha >= '" & fecha1 & "' AND fecha <='" & fecha2 & "' order by system_table_schema,system_table_name,Fecha ", thisConnection12)

            Dim thisReader As iDB2DataReader
            thisReader = thisCommand.ExecuteReader()
            Dim dt As New DataTable("unionasphi")
            dt.Load(thisReader)
            DataGridView4.DataSource = dt
            Label11.Visible = False
            Label11.Refresh()

            If DataGridView4.Rows.Count = 1 Then
                MsgBox("There are not  files found with smaller variations to 1Gb ", , "Decrease Files ")
            End If


            '-----------------------------------------------------------------------------------
            '-----------------------------------------------------------------------------------

            ' pruebo el grafico de chart 

            Label32.Visible = False
            Label32.Refresh()
            Label30.Visible = True
            Label31.Visible = False
            Label30.Text = "Decrease Files"
            Label30.Refresh()
            Chart2.Visible = False                                  'cambio a chart1
            Chart1.Visible = True                                   'cambio a chart2
            Chart1.Series("File").XValueMember = "Archivo"          'cambio a chart2
            Chart1.Series("File").YValueMembers = "Decrease_GB"       'cambio a chart2
            Chart1.Series("File").Points.AddXY("Archivo", "Decrease_GB") 'cambio a chart2


            Chart1.DataSource = dt                                  'cambio a chart2

            '-----------------------------------------------------------
            'prueba cambiar el chrttype 



            Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.StackedColumn  'cambio a chart2

            '------------------------------------------------------------------
            '------------------------------------------------------------------







        Catch ex As Exception

            MsgBox("Check, the loaded data is wrong  " & vbCrLf & ex.Message)
        End Try
salir:
    End Sub

    Private Sub Button24_Click(sender As System.Object, e As System.EventArgs) Handles Button24.Click
        'MsgBox("Este proceso puede demorar algunos minutos...presione aceptar", , "Exporto")
        ' Label6.Visible = True
        ' Label6.Refresh()
        ' aca va el codigo ---------------------------------------

        Try
            Dim iExp As New funciones
            iExp.DataTableToExcel(CType(Me.DataGridView4.DataSource, DataTable))

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


        ' --------------------------------------------------------
        'Label6.Visible = False
    End Sub

    Private Sub Button23_Click(sender As System.Object, e As System.EventArgs) Handles Button23.Click

        If DataGridView4.RowCount = 0 Then
            MessageBox.Show("El datagridview esta vacio")
        Else
            If Directory.Exists("C:\as400sql") = False Then ' si no existe la carpeta se crea
                Directory.CreateDirectory("C:\as400sql")
            End If
            Dim sFile As String = "C:\as400sql\Salidatexto.txt"
            If File.Exists(sFile) = True Then 'Si el archivo existe, lo elimina antes
                My.Computer.FileSystem.DeleteFile(sFile, FileIO.UIOption.OnlyErrorDialogs, _
                                                  FileIO.RecycleOption.DeletePermanently, FileIO.UICancelOption.DoNothing)
            End If


            'Const Dat As String = ("C:\Registro.txt")
            ' GERENANDO EL ARCHIVO 
            Using f As New IO.StreamWriter(sFile, True)

                ' AGREGANDO LAS COLUMNAS 
                Dim col As String = ""
                ' AGREGANDO LAS FILAS 
                Dim row As String = ""
                Dim i As Integer = 0
                For Each r As DataGridViewRow In DataGridView4.Rows
                    For Each c As DataGridViewColumn In DataGridView4.Columns

                        'row = row & "'" & Convert.ToString(r.Cells(c.HeaderText).Value) & vbTab
                        row = row & Convert.ToString(r.Cells(c.HeaderText).Value) & vbTab
                    Next
                    If i < DataGridView4.Rows.Count - 1 Then row &= Environment.NewLine
                Next

                'AGREGANDO LA INFORMACION 
                f.WriteLine(row)
                MessageBox.Show("El archivo SALIDATEXTO.txt ha sido creado en la carpeta C:\as400sql ")
            End Using
        End If
    End Sub

    Private Sub Button22_Click(sender As System.Object, e As System.EventArgs) Handles Button22.Click
        If DataGridView4.RowCount = 0 Then
            MessageBox.Show("El datagridview esta vacio")
        Else
            If Directory.Exists("C:\as400sql") = False Then ' si no existe la carpeta se crea
                Directory.CreateDirectory("C:\as400sql")
            End If
            Dim sFile As String = "C:\as400sql\SalidaCSV.csv"
            If File.Exists(sFile) = True Then 'Si el archivo existe, lo elimina antes
                My.Computer.FileSystem.DeleteFile(sFile, FileIO.UIOption.OnlyErrorDialogs, _
                                                  FileIO.RecycleOption.DeletePermanently, FileIO.UICancelOption.DoNothing)
            End If


            'Const Dat As String = ("C:\Registro.txt")
            ' GERENANDO EL ARCHIVO 
            Using f As New IO.StreamWriter(sFile, True)

                ' AGREGANDO LAS COLUMNAS 
                Dim col As String = ""
                ' AGREGANDO LAS FILAS 
                Dim row As String = ""
                Dim i As Integer = 0
                For Each r As DataGridViewRow In DataGridView4.Rows
                    For Each c As DataGridViewColumn In DataGridView4.Columns

                        'row = row & "'" & Convert.ToString(r.Cells(c.HeaderText).Value) & vbTab
                        row = row & Convert.ToString(r.Cells(c.HeaderText).Value) & ","
                    Next
                    If i < DataGridView4.Rows.Count - 1 Then row &= Environment.NewLine
                Next

                'AGREGANDO LA INFORMACION 
                f.WriteLine(row)
                MessageBox.Show("El archivo SALIDACSV.csv ha sido creado en la carpeta C:\as400sql ")
            End Using
        End If
    End Sub

    Private Sub Button25_Click(sender As System.Object, e As System.EventArgs) Handles Button25.Click

        Chart2.Visible = False
        Chart1.Visible = False
        Label31.Visible = False
        Label30.Visible = False
        Label32.Visible = False
        Label31.Refresh()
        Label30.Refresh()
        Label32.Refresh()
        Dim conector As String
        Dim ip As String
        If TextBox4.Text = "" Or TextBox5.Text = "" Then
            MsgBox("You must complete the fields User and Password ", , "ASP")
            GoTo salir
        End If

        If marcaesta = 0 Then

            MsgBox("You must select one Lpar ", , "SQL")
            GoTo salir
        End If

        ip = ip2

        userx = TextBox4.Text
        passx = TextBox5.Text

        Dim userpass As String
        userpass = "userid=" + userx + ";" + "password=" + passx + ";"


        Dim ejecutox As String
        Dim ejecutox2 As String

        Dim copia As String
        Dim copia2 As String
        Dim copia22 As String



        userpass = "userid=" + userx + ";" + "password=" + passx + ";"

        conector = "DataSource=" + ip + ";" + " AllowUnsupportedChar=true" + ";"

        Label11.Enabled = True
        Label11.Visible = True

        Label11.Refresh()
        Try
            Dim thisConnection12 As New iDB2Connection(
                  conector +
                   userpass +
                  "LibraryList=" + "isysmodobj")
            thisConnection12.Open()



            Dim archispool As String
            Dim jobnum As String
            Dim user As String
            Dim jobnombre As String
            Dim fecha1 As String
            Dim fecha2 As String


            fecha1 = DateTimePicker13.Value.ToString("yyyy-MM-dd")
            fecha2 = DateTimePicker12.Value.ToString("yyyy-MM-dd")


            'Try


            'Dim thisCommand As New iDB2Command("SELECT system_table_schema as Library, system_table_name as Archivo, Fecha, Data_size_GB, Fecha01, Data_siz0001, Aument_GB FROM isysmodobj.unionasphi where aument_gb >0 and  fecha >= '" & fecha1 & "' AND fecha <='" & fecha2 & "'  ", thisConnection12)
            Dim thisCommand As New iDB2Command("SELECT  char(Fecha,iso) as Fecha, bibliot, tamano_gb, cant_obj, Char(fecha01,iso) as Fecha2, bibliot01, tamano_gb1, cant_obj1, incr_gb, incr_obj   FROM isysmodobj.histlib where INCR_GB > 0 and  fecha >= '" & fecha1 & "' AND fecha <='" & fecha2 & "' order by BIBLIOT,Fecha ", thisConnection12)

            Dim thisReader As iDB2DataReader
            thisReader = thisCommand.ExecuteReader()
            Dim dt As New DataTable("histlib")
            dt.Load(thisReader)
            DataGridView5.DataSource = dt
            Label11.Visible = False
            Label11.Refresh()

            If DataGridView5.Rows.Count = 1 Then
                MsgBox("There are not  Libs found with increase variations > 1Gb ", , "Increase Lib ")
            End If


            '-----------------------------------------------------------------------------------
            '-----------------------------------------------------------------------------------

            ' pruebo el grafico de chart 

            Label32.Visible = False
            Label32.Refresh()
            Label31.Visible = True
            Label30.Visible = False
            Label31.Text = "Increase Libs"
            Label31.Refresh()


            Chart1.Visible = False                                  'cambio a chart1
            Chart2.Visible = True                                   'cambio a chart2
            '---------prueba-------------------------------------------------
            ' Dim Series1 As Series = Chart1.Series("Series1")
            ' '~~> Setting the series Name
            ' Series1.Name = "Sales"
            '----------------------------------------------------------------

            Chart2.Series("Objects").XValueMember = "Bibliot"          'cambio a chart2
            Chart2.Series("Objects").YValueMembers = "Incr_GB"       'cambio a chart2
            Chart2.Series("Objects").Points.AddXY("Bibliot", "Incr_GB") 'cambio a chart2


            Chart2.DataSource = dt                                  'cambio a chart2

            '-----------------------------------------------------------
            'prueba cambiar el chrttype 



            Chart2.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.StackedColumn  'cambio a chart2

            '------------------------------------------------------------------
            '------------------------------------------------------------------







        Catch ex As Exception

            MsgBox("Check, the loaded data is wrong  " & vbCrLf & ex.Message)
        End Try
salir:
    End Sub

    Private Sub Button28_Click(sender As System.Object, e As System.EventArgs) Handles Button28.Click
        'MsgBox("Este proceso puede demorar algunos minutos...presione aceptar", , "Exporto")
        ' Label6.Visible = True
        ' Label6.Refresh()
        ' aca va el codigo ---------------------------------------

        Try
            Dim iExp As New funciones
            iExp.DataTableToExcel(CType(Me.DataGridView5.DataSource, DataTable))

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


        ' --------------------------------------------------------
        'Label6.Visible = False
    End Sub

    Private Sub Button27_Click(sender As System.Object, e As System.EventArgs) Handles Button27.Click
        If DataGridView5.RowCount = 0 Then
            MessageBox.Show("El datagridview esta vacio")
        Else
            If Directory.Exists("C:\as400sql") = False Then ' si no existe la carpeta se crea
                Directory.CreateDirectory("C:\as400sql")
            End If
            Dim sFile As String = "C:\as400sql\Salidatexto.txt"
            If File.Exists(sFile) = True Then 'Si el archivo existe, lo elimina antes
                My.Computer.FileSystem.DeleteFile(sFile, FileIO.UIOption.OnlyErrorDialogs, _
                                                  FileIO.RecycleOption.DeletePermanently, FileIO.UICancelOption.DoNothing)
            End If


            'Const Dat As String = ("C:\Registro.txt")
            ' GERENANDO EL ARCHIVO 
            Using f As New IO.StreamWriter(sFile, True)

                ' AGREGANDO LAS COLUMNAS 
                Dim col As String = ""
                ' AGREGANDO LAS FILAS 
                Dim row As String = ""
                Dim i As Integer = 0
                For Each r As DataGridViewRow In DataGridView5.Rows
                    For Each c As DataGridViewColumn In DataGridView5.Columns

                        'row = row & "'" & Convert.ToString(r.Cells(c.HeaderText).Value) & vbTab
                        row = row & Convert.ToString(r.Cells(c.HeaderText).Value) & vbTab
                    Next
                    If i < DataGridView5.Rows.Count - 1 Then row &= Environment.NewLine
                Next

                'AGREGANDO LA INFORMACION 
                f.WriteLine(row)
                MessageBox.Show("El archivo SALIDATEXTO.txt ha sido creado en la carpeta C:\as400sql ")
            End Using
        End If
    End Sub

    Private Sub Button26_Click(sender As System.Object, e As System.EventArgs) Handles Button26.Click
        If DataGridView5.RowCount = 0 Then
            MessageBox.Show("El datagridview esta vacio")
        Else
            If Directory.Exists("C:\as400sql") = False Then ' si no existe la carpeta se crea
                Directory.CreateDirectory("C:\as400sql")
            End If
            Dim sFile As String = "C:\as400sql\SalidaCSV.csv"
            If File.Exists(sFile) = True Then 'Si el archivo existe, lo elimina antes
                My.Computer.FileSystem.DeleteFile(sFile, FileIO.UIOption.OnlyErrorDialogs, _
                                                  FileIO.RecycleOption.DeletePermanently, FileIO.UICancelOption.DoNothing)
            End If


            'Const Dat As String = ("C:\Registro.txt")
            ' GERENANDO EL ARCHIVO 
            Using f As New IO.StreamWriter(sFile, True)

                ' AGREGANDO LAS COLUMNAS 
                Dim col As String = ""
                ' AGREGANDO LAS FILAS 
                Dim row As String = ""
                Dim i As Integer = 0
                For Each r As DataGridViewRow In DataGridView5.Rows
                    For Each c As DataGridViewColumn In DataGridView5.Columns

                        'row = row & "'" & Convert.ToString(r.Cells(c.HeaderText).Value) & vbTab
                        row = row & Convert.ToString(r.Cells(c.HeaderText).Value) & ","
                    Next
                    If i < DataGridView5.Rows.Count - 1 Then row &= Environment.NewLine
                Next

                'AGREGANDO LA INFORMACION 
                f.WriteLine(row)
                MessageBox.Show("El archivo SALIDACSV.csv ha sido creado en la carpeta C:\as400sql ")
            End Using
        End If
    End Sub
End Class
