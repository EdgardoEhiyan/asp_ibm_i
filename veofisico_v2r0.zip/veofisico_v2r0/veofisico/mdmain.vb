﻿Imports IBM.Data.DB2
Imports Microsoft.VisualBasic
Imports System
Imports System.Data
Module mdmain
    Public userx As String
    Public passx As String
    Public ip2 As String
    Public marcaesta As Integer
    Public borrar As Integer


End Module
